﻿using ExcelDemo.Models;
using ExcelInOutput;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Diagnostics;

namespace ExcelDemo.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        public IActionResult DownExcel()
        {
            var list = Student.GetStudents();
            var excelHeper = new ExcelHelper();
            var config = new List<ExcelGridModel> {
                 new ExcelGridModel{name="Id",label="学号", align="left",},
                  new ExcelGridModel{name="Name",label="姓名", align="left",},
                   new ExcelGridModel{name="IsBanZhang",label="是否班长", align="left",},
            };
        
            var fileName = "a.excel";

           return excelHeper.ExcelDownload(list, config, fileName);
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        class Student
        {
            public int Id { get; set; }

            public string Name { get; set; }

            public bool IsBanZhang { get; set; }

            public static IEnumerable<Student> GetStudents()
            {
                return new List<Student>
                {
                      new Student{Name="小强",Id=1,IsBanZhang=false},
                new Student{Name="小文",Id=2,IsBanZhang=true},
                new Student{Name="小黄",Id=3,IsBanZhang=false},
                new Student{Name="小刚",Id=3,IsBanZhang=false},
                };
            }
        }
    }
}
