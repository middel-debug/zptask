# 项目说明

此项目为【运维咖啡吧】小程序v0.0.5版本源码

可通过扫描下方二维码体验小程序

![欢迎关注微信公众号【运维咖啡吧】](/images/miniprogram.jpg)

当然也欢迎你关注作者微信公众号，里边有更多干货内容

![欢迎关注微信公众号【运维咖啡吧】](/images/qrcode.jpg)


配合对应文章看源码更有效，文章地址：[直达链接，点我查看](https://mp.weixin.qq.com/s/fewb1jDso_FKPqhu9P1uHA)