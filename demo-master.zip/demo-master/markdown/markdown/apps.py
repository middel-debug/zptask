from django.apps import AppConfig


class MarkdownConfig(AppConfig):
    name = 'markdown'
