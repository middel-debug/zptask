from django.apps import AppConfig


class OpsCoffeeConfig(AppConfig):
    name = 'ops_coffee'
