from django.apps import AppConfig


class PasswordConfig(AppConfig):
    name = 'password'
