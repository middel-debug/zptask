﻿namespace System.Data.OleDb
{
    public class OleDbDataReader
    {
        internal DataTable GetSchemaTable()
        {
            throw new NotImplementedException();
        }
    }
}