﻿namespace System.Data.OleDb
{
    internal class OleDbSchemaGuid
    {
        public static object Columns { get; internal set; }
        public static object Tables { get; internal set; }
        public static object Views { get; internal set; }
    }
}