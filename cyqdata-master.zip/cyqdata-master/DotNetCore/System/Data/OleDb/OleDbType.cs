﻿namespace System.Data.OleDb
{
    internal class OleDbType
    {
        public static object DBTimeStamp { get; internal set; }
    }
}