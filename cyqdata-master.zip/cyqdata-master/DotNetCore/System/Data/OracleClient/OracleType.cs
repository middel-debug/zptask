﻿namespace CYQ.Data
{
    internal class OracleType
    {
        public static object Int32 { get; internal set; }
        public static object NClob { get; internal set; }
        public static object Clob { get; internal set; }
        public static object Cursor { get; internal set; }
        public static object NVarChar { get; internal set; }
    }
}