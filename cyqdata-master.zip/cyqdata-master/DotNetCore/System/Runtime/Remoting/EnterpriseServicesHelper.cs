﻿using System;
using System.Runtime.Remoting.Activation;
using System.Runtime.Remoting.Messaging;

namespace System.Runtime.Remoting.Services
{
    internal class EnterpriseServicesHelper
    {
        internal static IMessage CreateConstructionReturnMessage(IConstructionCallMessage constructCallMsg, MarshalByRefObject marshalByRefObject)
        {
            throw new NotImplementedException();
        }
    }
}