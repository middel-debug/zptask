﻿namespace System.Runtime.Remoting.Activation
{
    internal interface IConstructionCallMessage
    {
    }
}