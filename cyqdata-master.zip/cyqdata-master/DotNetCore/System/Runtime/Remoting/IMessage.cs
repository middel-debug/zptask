﻿namespace System.Runtime.Remoting.Messaging
{
    public interface IMessage
    {
    }
}