﻿namespace System.Web.UI.WebControls
{
    internal class Control
    {
        internal Control FindControl(string v)
        {
            throw new NotImplementedException();
        }
    }
}