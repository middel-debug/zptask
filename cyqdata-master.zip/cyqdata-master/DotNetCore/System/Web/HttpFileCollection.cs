﻿using CYQ.Data.Tool;
namespace System.Web
{
    public class HttpFileCollection:MDictionary<string,HttpPostedFile>
    {

    }
}
