using System;

namespace CYQ.Data.Table
{
    [Serializable]
    public partial class MDataTable
    {

    }
    [Serializable]
    public partial class MDataRow
    {

    }
    [Serializable]
    public partial class MDataCell
    {

    }
    [Serializable]
    public partial class MCellStruct
    {

    }

    [Serializable]
    internal partial class MCellValue
    {

    }

    [Serializable]
    public partial class MDataColumn
    {

    }
    [Serializable]
    public partial class MDataRowCollection
    {

    }

    [Serializable]
    internal partial class MDataView
    {

    }
    [Serializable]
    internal partial class MDataProperty
    {

    }
}
